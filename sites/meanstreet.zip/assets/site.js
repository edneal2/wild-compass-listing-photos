/* Email signup. Paste your Kit form ID between the quotes to switch the forms on. */
var KIT_FORM_ID = "";
document.querySelectorAll('form[data-kit]').forEach(function(f){var m=f.nextElementSibling;
if(KIT_FORM_ID){f.action='https://app.kit.com/forms/'+KIT_FORM_ID+'/subscriptions';}
f.addEventListener('submit',function(e){var v=f.email_address.value.trim();
if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(v)){e.preventDefault();m.textContent='Please enter a valid email address.';return;}
if(!KIT_FORM_ID){e.preventDefault();m.textContent='Signups open shortly. For now, email hello@meanstreetanalytics.com and we’ll add you.';}});});
