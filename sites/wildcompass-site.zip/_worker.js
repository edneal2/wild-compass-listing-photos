// Etsy API relay for the shop owner's own tools. Forwards only to Etsy's v3 API,
// only for requests coming from etsy.com pages, and stores nothing.
const ALLOWED_ORIGINS = ['https://www.etsy.com'];
const cors = (origin) => ({
  'Access-Control-Allow-Origin': origin,
  'Access-Control-Allow-Methods': 'GET,POST,PUT,PATCH,DELETE,OPTIONS',
  'Access-Control-Allow-Headers': 'x-api-key,authorization,content-type',
  'Access-Control-Max-Age': '600',
  'Vary': 'Origin',
});
export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    if (url.pathname.startsWith('/etsy-proxy/')) {
      const origin = request.headers.get('Origin') || '';
      if (!ALLOWED_ORIGINS.includes(origin)) return new Response('forbidden', { status: 403 });
      if (request.method === 'OPTIONS') return new Response(null, { status: 204, headers: cors(origin) });
      const path = url.pathname.slice('/etsy-proxy'.length);
      if (!path.startsWith('/v3/')) return new Response('bad path', { status: 400, headers: cors(origin) });
      const host = path.startsWith('/v3/public/oauth/') ? 'https://api.etsy.com' : 'https://openapi.etsy.com';
      const headers = new Headers();
      for (const h of ['x-api-key', 'authorization', 'content-type']) {
        const v = request.headers.get(h); if (v) headers.set(h, v);
      }
      const init = { method: request.method, headers };
      if (!['GET', 'HEAD'].includes(request.method)) init.body = await request.arrayBuffer();
      const resp = await fetch(host + path + url.search, init);
      const out = new Headers(cors(origin));
      const ct = resp.headers.get('content-type'); if (ct) out.set('content-type', ct);
      return new Response(resp.body, { status: resp.status, headers: out });
    }
    return env.ASSETS.fetch(request);
  },
};
