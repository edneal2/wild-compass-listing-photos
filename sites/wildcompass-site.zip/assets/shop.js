(async()=>{
const C=await (await fetch('catalog.json')).json();
const g=document.getElementById('grid'),q=document.getElementById('q'),so=document.getElementById('sort'),cnt=document.getElementById('count'),more=document.getElementById('more'),chips=document.getElementById('chips');
let sec=(location.hash||'#all').slice(1)||'all', shown=48, list=[];
const esc=s=>s.replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
function setChip(){[...chips.children].forEach(b=>b.classList.toggle('on',b.dataset.s===sec));}
function filter(){
  const t=q.value.trim().toLowerCase().split(/\s+/).filter(Boolean);
  list=C.filter(c=>(sec==='all'||c.sec===sec)&&t.every(w=>(c.full+' '+c.s).toLowerCase().includes(w)));
  if(so.value==='lo')list.sort((a,b)=>a.p-b.p); else if(so.value==='hi')list.sort((a,b)=>b.p-a.p); else if(so.value==='az')list.sort((a,b)=>a.t.localeCompare(b.t));
  render();
}
function render(){
  g.innerHTML=list.slice(0,shown).map(c=>`<a class='card' href='https://www.etsy.com/listing/${c.id}' target='_blank' rel='noopener'><span class='ph'><img src='${c.img}' alt='${esc(c.t)}' loading='lazy' width='720' height='540'></span><span class='ct'>${esc(c.t)}</span><span class='cp'>$${c.p.toFixed(2)}<span class='on'>on Etsy</span></span></a>`).join('');
  cnt.textContent=list.length+(list.length===1?' design':' designs');
  more.style.display=list.length>shown?'':'none';
}
chips.addEventListener('click',e=>{const b=e.target.closest('button');if(!b)return;sec=b.dataset.s;shown=48;history.replaceState(null,'','#'+sec);setChip();filter();});
q.addEventListener('input',()=>{shown=48;filter();});so.addEventListener('change',filter);
more.addEventListener('click',()=>{shown+=48;render();});
window.addEventListener('hashchange',()=>{sec=location.hash.slice(1)||'all';setChip();filter();});
setChip();filter();
})();
